
<?php 
	require 'includes/config.php';
	
	if (isset($_SESSION['user'])){
			
		}else{
			$config['base_url'] = ((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == "on") ? "https" : "http");
			$config['base_url'] .= "://".$_SERVER['HTTP_HOST'];
			$config['base_url'] .= str_replace(basename($_SERVER['SCRIPT_NAME']),"",$_SERVER['SCRIPT_NAME']);

			
			$redirect = $config['base_url'];
			
			
			
			header("Location: $redirect");
			exit();
		}
?>






<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
	<link rel="icon"  href="assets/images/logo-sm.png">
    <meta content="" name="keywords">
    <meta content="" name="description">
    <title>Customer</title>
    <script src="assets/js/layout.js"></script>
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <link href="assets/css/style.css" rel="stylesheet">
    <link href="assets/css/app.min.css" rel="stylesheet" type="text/css" />
    <link href="assets/css/custom.min.css" rel="stylesheet" type="text/css" />
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">
    <link href="lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />
	<link href="assets/css/lobibox.css" rel="stylesheet" type="text/css" />
	
</head>

<body>
    <div class="container-xxl position-relative d-flex p-0">
        
		<div class="sidebar">
            <nav class="navbar navbar-light ">
                <div class="navbar-nav w-100">
                    <a href="#" class="navbar-brand mb-3" style="text-align:center;color:#fff">
                    LuLu Mall
                </a>
               
              
                     <a href="dashboard.php" class="nav-item nav-link active"><i class="fas fa-chart-pie"></i> Dashboard</a>
                    
                </div>

                <div class="navbar-nav w-100 bottom-nav">
                    <a href="user.php" class="nav-item nav-link"><i class="fas fa-user"></i> User</a>
                    
                    <a href="logout.php" class="nav-item nav-link"><img src="img/user.jpg"> Log Out</a>
                </div>
            </nav>
        </div>
		
		
        <div class="content dashboard-right-col">
            <nav class="navbar navbar-expand bg-light navbar-light sticky-top px-4 py-0">
                <a href="#" class="sidebar-toggler flex-shrink-0">
                    <i class="fa fa-bars"></i>
                </a>
                <p class="wlcm-txt"><span>Hi <?=$_SESSION['u_name']?>,</span> Welcome Back!</p>
                <div class="navbar-nav align-items-center ms-auto top-bar-navigation mob-hide">
                    

                    <?php 
						$sql = 'SELECT *
						FROM store_users
						WHERE id = :id';
						
						$statement = $pdo->prepare($sql);
						$statement->bindParam(':id', $_SESSION['user'], PDO::PARAM_INT);
						$statement->execute();
						$user_balance    = $statement->fetch(PDO::FETCH_ASSOC);
							if($user_balance){
								if($user_balance['wallet'] !=0){
									$bal = $user_balance['wallet'];
								}else{
									$bal = '0.00';
								}
							}else{
								$bal = '0.00';
							}
						if($_SESSION['u_hierarchy'] == 6){
						}else{
					?>
					
                    <button class="btn"> Balance : RS <?=$bal;?>   </button>
					
						<?php } ?>
					
					
                </div>
            </nav>

            <div class="container mob-show">
                <div class="row">
                    <div class="col-lg-12">
                    <div class="navbar-nav align-items-center ms-auto top-bar-navigation">
                        <select>
                            <option>Property</option>
                            <option>Property</option>
                            <option>Property</option>
                        </select>
    
                        <select>
                            <option>Portfolio</option>
                            <option>Portfolio</option>
                            <option>Portfolio</option>
                        </select>

                        <select>
                            <option>View As</option>
                            <option>View As</option>
                        <option>View As</option>
                        </select>
                      </div>
                      <button class="btn w-100"><i class="fas fa-cog"></i> Customize Dashboard</button>
                    </div>
                </div>
            </div>

            <div class="container-fluid pt-4 px-4">
                
              <div class="page-content">
                <div class="container-fluid">

                    

                    <div class="row">
                        <div class="col-xxl-3">
                            
                            
                            
                        </div>
                        <!--end col-->
                        <div class="col-xxl-9">
                            <div class="card mt-xxl-n5" >
                                <div class="card-header">
                                    <ul class="nav nav-tabs-custom rounded card-header-tabs border-bottom-0" role="tablist">
                                        
										<?php 
											if($_SESSION['u_hierarchy'] == 1){
										?>
										<li class="nav-item">
                                            <a class="nav-link " data-bs-toggle="tab" href="#personalDetails" role="tab">
                                                Create User 
                                            </a>
                                        </li>
										
										<?php 
											}
										?>
										
                                        <li class="nav-item">
                                            <a class="nav-link active" data-bs-toggle="tab" href="#changePassword" role="tab">
                                                User List
                                            </a>
                                        </li>
										<?php 
											if($_SESSION['u_hierarchy'] == 6){
												
											}else{
										?>
										
                                        <li class="nav-item">
                                            <a class="nav-link" data-bs-toggle="tab" href="#loginhistory" role="tab">
                                                Transcation  History
                                            </a>
                                        </li>
										
											<?php } ?>
										
										<?php 
											if($_SESSION['u_hierarchy'] == 1){
										?>
                                        <li class="nav-item">
                                            <a class="nav-link" data-bs-toggle="tab" href="#experience" role="tab">
                                                Hierarchy List
                                            </a>
                                        </li>
											<?php } ?>
										
                                        <!--<li class="nav-item">
                                            <a class="nav-link" data-bs-toggle="tab" href="#privacy" role="tab">
                                                Privacy Policy
                                            </a>
                                        </li>-->
                                    </ul>
                                </div>
                                <div class="card-body p-4" style="min-height:400px">
                                    <div class="tab-content">
									
									<?php 
										if($_SESSION['u_hierarchy'] == 1){
									?>
									
                                        <div class="tab-pane " id="personalDetails" role="tabpanel">
                                            
											
											
											
											
											<form  id="create_user" method="post">
											
                                                <div class="row">
                                                    <div class="col-lg-6">
                                                        <div class="mb-3">
                                                            <label for="name" class="form-label"> Name</label>
                                                            <input type="text" class="form-control" id="name" placeholder="User Name" name="name">
                                                        </div>
                                                    </div>
                                                    <!--end col-->
                                                    <div class="col-lg-6">
                                                       <div class="mb-3">
                                                            <label for="emailInput" class="form-label">Email Address</label>
                                                            <input type="email" class="form-control" id="emailInput" placeholder="Email Address" name="email">
                                                        </div>
                                                    </div>
                                                    
                                                    <div class="col-lg-6">
                                                       <div class="mb-3">
                                                            <label for="emailInput" class="form-label">Password</label>
                                                            <input type="text" class="form-control" id="password" placeholder="Password" name="password">
                                                        </div>
                                                    </div>
													
													<div class="col-lg-6">
                                                       <div class="mb-3">
                                                            <label for="emailInput" class="form-label">Confirm Password</label>
                                                            <input type="text" class="form-control" id="cPassword" placeholder="Confirm Password" name="cPassword">
                                                        </div>
                                                    </div>
													
													<?php 
														$sql = 'SELECT * FROM hierarchy';
														$statement = $pdo->query($sql);
														
														$hierarchy = $statement->fetchAll(PDO::FETCH_ASSOC);
														
														if($hierarchy){
															
														}
													?>
													<div class="col-md-6">
                                                    <div class="mb-3">
                                                        <label for="hierarchy" class="form-label">Hierarchy(Role)</label>
                                                        <select id="hierarchy" class="form-select" name="hierarchy" data-choices="" data-choices-sorting="true">
                                                            <option value="0" selected="">Choose...</option>
                                                            <?php 
																if($hierarchy){
																	foreach($hierarchy as $role){
															?>
															
															<option value="<?=$role['id'];?>"><?=$role['name'];?></option>
																<?php 
																	}
																} ?>
															
                                                        </select>
                                                    </div>
                                                </div>
                                                    
                                                   
                                                    <div class="col-lg-12"><hr></div>

                                                    <!--end col-->
                                                    
                                                    <!--end col-->
                                                    <div class="col-lg-12">
                                                        <div class="hstack gap-2 justify-content-end">
                                                            <button type="submit" class="btn btn-primary">Create</button>
                                                            <button type="button" class="btn btn-soft-success">Cancel</button>
                                                        </div>
                                                    </div>
                                                    <!--end col-->
                                                </div>
                                                <!--end row-->
                                            </form>
                                        </div>
										<?php 
										}
										?>
										
                                        <!--end tab-pane-->
                                        <div class="tab-pane active" id="changePassword" role="tabpanel">
                                           <table id="user" class="table table-bordered dt-responsive nowrap align-middle mdl-data-table" style="width:100%">
                                        <thead>
                                            <tr>
                                                
                                                <th>Name</th>
                                                <th>E-mail</th>
                                                
                                                <th>Hierarchy</th>
                                                <th>Created at</th>
                                                <th>Balance</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
										
										<?php 
										
												if($_SESSION['u_hierarchy'] == 1){
														$sql = 'SELECT * FROM store_users';
														$statement = $pdo->query($sql);
														
														$users = $statement->fetchAll(PDO::FETCH_ASSOC);
														
														if($users){
															foreach($users as $u){
														
													?>
										
                                            <tr>
                                                <td><?=$u['name'];?></td>
                                                <td><?=$u['email'];?></td>
                                                
                                                <td><?php
												$sql = 'SELECT * 
												FROM hierarchy
												WHERE id = :id';
												
												$statement = $pdo->prepare($sql);
												$statement->bindParam(':id', $u['hierarchy'], PDO::PARAM_INT);
												$statement->execute();
												$one    = $statement->fetch(PDO::FETCH_ASSOC);
												if($one){
												?>
												
												<?=$one['name'];?></td>
												
												<?php }?>
                                                
                                                <td><?=$u['created_at'];?></td>
                                                <td>RS.<?=$u['wallet'];?></td>
                                                <td><a onclick="edit_user('<?=$u['id']?>')" style="cursor:pointer" class="text-primary fs-12"><i class="fas fa-edit"></i></a>
												<a onclick="delete_user('<?=$u['id']?>')" style="cursor:pointer" class="text-primary fs-12"><i class="fas fa-trash"></i></a>
												</td>
                                            </tr>
											
											<?php 
												}
												}
												}else{
													
													$sql = 'SELECT *
													FROM store_users
													WHERE id = :id';
													
													$statement = $pdo->prepare($sql);
													$statement->bindParam(':id', $_SESSION['user'], PDO::PARAM_INT);
													$statement->execute();
													$user_1    = $statement->fetch(PDO::FETCH_ASSOC);
											?>
												 <tr>
                                                <td><?=$user_1['name'];?></td>
                                                <td><?=$user_1['email'];?></td>
                                                
                                                <td><?php
												
												$sql = 'SELECT * 
												FROM hierarchy
												WHERE id = :id';
												
												$statement = $pdo->prepare($sql);
												$statement->bindParam(':id', $user_1['hierarchy'], PDO::PARAM_INT);
												$statement->execute();
												$one    = $statement->fetch(PDO::FETCH_ASSOC);
												
												if($one){
												?>
												
												<?=$one['name'];?></td>
												
												<?php }?>
                                                
                                                <td><?=$user_1['created_at'];?></td>
                                                <td>RS.<?=$user_1['wallet'];?></td>
                                                <td><a onclick="edit_user('<?=$user_1['id']?>')" style="cursor:pointer" class="text-primary fs-12"><i class="fas fa-edit"></i></a>
												</td>
                                            </tr>
											
												<?php } ?>
                                            
                                        </tbody>
                                    </table>
                                        </div>
                                        <!--end tab-pane-->

                                        <!--end tab-pane-->
                                        <div class="tab-pane" id="loginhistory" role="tabpanel">
                                            <table id="transcation" class="table table-bordered dt-responsive nowrap align-middle mdl-data-table" style="width:100%">
                                        <thead>
                                            <tr>
                                                
                                                <th>Id</th>
                                                <th>Sale Amount</th>
                                                <th>Commission Amount</th>
                                                <th>Credited From</th>
                                                <th>Created at</th>
                                                
                                            </tr>
                                        </thead>
                                        <tbody>
											<?php 
											
												$sth = $pdo->prepare('SELECT * FROM transaction
												WHERE user_id = ? ');
												$sth->execute([$_SESSION['user']]);
												$transaction = $sth->fetchAll();
											
											
												
												
														
														foreach($transaction as $tr){
											?>
										
                                            <tr>
                                                <td><?=$tr['id'];?></td>
                                                <td><?=$tr['sale_amount'];?></td>
                                                <td><?=$tr['commision_amount'];?></td>
												
												<?php 
													$sql = 'SELECT * 
														FROM store_users
														WHERE id = :id';
																				
												$statement = $pdo->prepare($sql);
												$statement->bindParam(':id', $tr['t_from'], PDO::PARAM_INT);
												$statement->execute();
												$one    = $statement->fetch(PDO::FETCH_ASSOC);
												?>
                                                
                                                <td><span style="color:green;"><?=$one['name'];?></span></td>
												<td><?=$tr['created_at'];?></td>
                                            </tr>
														<?php } ?>
                                        </tbody>
                                    </table>
                                        </div>
                                        <!--end tab-pane-->
 

                                        <div class="tab-pane" id="experience" role="tabpanel">
                                            <table id="hie" class="table table-bordered dt-responsive nowrap align-middle mdl-data-table" style="width:100%">
                                        <thead>
                                            <tr>
                                                <th>ID</th>
                                                <th>Name</th>
                                                <th>Commission</th>
                                                <th>Status</th>
                                                
                                            </tr>
                                        </thead>
                                        <tbody>
										
										<?php 
																if($hierarchy){
																	foreach($hierarchy as $role){
															?>
															
																
																<tr>
																<td><?=$role['id'];?></td>
                                                <td><?=$role['name'];?></td>
                                                <td><?=$role['commision_percentage'];?> %</td>
                                                
                                                <td>
												<?php if($role['status'] == 1){
													?>
													<span class="badge  text-success">Active</span></td>
													<?php
												}else{
													?>
													<span class="badge  text-danger">In Active</span></td>
													<?php
												}
												
												?>
												
                                                
                                            </tr>
																
																
																
																
																<?php 
																	}
																} ?>
										
										
										
                                            
                                            
                                        </tbody>
                                    </table>
                                        </div>
                                        <!--end tab-pane-->
                                        <div class="tab-pane" id="privacy" role="tabpanel">
                                            <div class="mb-4 pb-2">
                                                <h5 class="card-title text-decoration-underline mb-3">Security:</h5>
                                                <div class="d-flex flex-column flex-sm-row mb-4 mb-sm-0">
                                                    <div class="flex-grow-1">
                                                        <h6 class="fs-15 mb-1">Two-factor Authentication</h6>
                                                        <p class="text-muted">Two-factor authentication is an enhanced security meansur. Once enabled, you'll be required to give two types of identification when you log into Google Authentication and SMS are Supported.</p>
                                                    </div>
                                                    <div class="flex-shrink-0 ms-sm-3">
                                                        <a href="javascript:void(0);" class="btn btn-sm btn-primary">Enable Two-facor Authentication</a>
                                                    </div>
                                                </div>
                                                <div class="d-flex flex-column flex-sm-row mb-4 mb-sm-0 mt-2">
                                                    <div class="flex-grow-1">
                                                        <h6 class="fs-15 mb-1">Secondary Verification</h6>
                                                        <p class="text-muted">The first factor is a password and the second commonly includes a text with a code sent to your smartphone, or biometrics using your fingerprint, face, or retina.</p>
                                                    </div>
                                                    <div class="flex-shrink-0 ms-sm-3">
                                                        <a href="javascript:void(0);" class="btn btn-sm btn-primary">Set up secondary method</a>
                                                    </div>
                                                </div>
                                                <div class="d-flex flex-column flex-sm-row mb-4 mb-sm-0 mt-2">
                                                    <div class="flex-grow-1">
                                                        <h6 class="fs-15 mb-1">Backup Codes</h6>
                                                        <p class="text-muted mb-sm-0">A backup code is automatically generated for you when you turn on two-factor authentication through your iOS or Android Twitter app. You can also generate a backup code on twitter.com.</p>
                                                    </div>
                                                    <div class="flex-shrink-0 ms-sm-3">
                                                        <a href="javascript:void(0);" class="btn btn-sm btn-primary">Generate backup codes</a>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="mb-3">
                                                <h5 class="card-title text-decoration-underline mb-3">Application Notifications:</h5>
                                                <ul class="list-unstyled mb-0">
                                                    <li class="d-flex">
                                                        <div class="flex-grow-1">
                                                            <label for="directMessage" class="form-check-label fs-14">Direct messages</label>
                                                            <p class="text-muted">Messages from people you follow</p>
                                                        </div>
                                                        <div class="flex-shrink-0">
                                                            <div class="form-check form-switch">
                                                                <input class="form-check-input" type="checkbox" role="switch" id="directMessage" checked />
                                                            </div>
                                                        </div>
                                                    </li>
                                                    <li class="d-flex mt-2">
                                                        <div class="flex-grow-1">
                                                            <label class="form-check-label fs-15" for="desktopNotification">
                                                                Show desktop notifications
                                                            </label>
                                                            <p class="text-muted">Choose the option you want as your default setting. Block a site: Next to "Not allowed to send notifications," click Add.</p>
                                                        </div>
                                                        <div class="flex-shrink-0">
                                                            <div class="form-check form-switch">
                                                                <input class="form-check-input" type="checkbox" role="switch" id="desktopNotification" checked />
                                                            </div>
                                                        </div>
                                                    </li>
                                                    <li class="d-flex mt-2">
                                                        <div class="flex-grow-1">
                                                            <label class="form-check-label fs-15" for="emailNotification">
                                                                Show email notifications
                                                            </label>
                                                            <p class="text-muted"> Under Settings, choose Notifications. Under Select an account, choose the account to enable notifications for. </p>
                                                        </div>
                                                        <div class="flex-shrink-0">
                                                            <div class="form-check form-switch">
                                                                <input class="form-check-input" type="checkbox" role="switch" id="emailNotification" />
                                                            </div>
                                                        </div>
                                                    </li>
                                                    <li class="d-flex mt-2">
                                                        <div class="flex-grow-1">
                                                            <label class="form-check-label fs-15" for="chatNotification">
                                                                Show chat notifications
                                                            </label>
                                                            <p class="text-muted">To prevent duplicate mobile notifications from the Gmail and Chat apps, in settings, turn off Chat notifications.</p>
                                                        </div>
                                                        <div class="flex-shrink-0">
                                                            <div class="form-check form-switch">
                                                                <input class="form-check-input" type="checkbox" role="switch" id="chatNotification" />
                                                            </div>
                                                        </div>
                                                    </li>
                                                    <li class="d-flex mt-2">
                                                        <div class="flex-grow-1">
                                                            <label class="form-check-label fs-15" for="purchaesNotification">
                                                                Show purchase notifications
                                                            </label>
                                                            <p class="text-muted">Get real-time purchase alerts to protect yourself from fraudulent charges.</p>
                                                        </div>
                                                        <div class="flex-shrink-0">
                                                            <div class="form-check form-switch">
                                                                <input class="form-check-input" type="checkbox"
                                                                    role="switch" id="purchaesNotification" />
                                                            </div>
                                                        </div>
                                                    </li>
                                                </ul>
                                            </div>
                                            <div>
                                                <h5 class="card-title text-decoration-underline mb-3">Delete This Account:</h5>
                                                <p class="text-muted">Go to the Data & Privacy section of your profile Account. Scroll to "Your data & privacy options." Delete your Profile Account. Follow the instructions to delete your account :</p>
                                                <div>
                                                    <input type="password" class="form-control" id="passwordInput" placeholder="Enter your password" value="make@321654987" style="max-width: 265px;">
                                                </div>
                                                <div class="hstack gap-2 mt-3">
                                                    <a href="javascript:void(0);" class="btn btn-soft-danger">Close & Delete This Account</a>
                                                    <a href="javascript:void(0);" class="btn btn-light">Cancel</a>
                                                </div>
                                            </div>
                                        </div>
                                        <!--end tab-pane-->
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--end col-->
                    </div>
                    <!--end row-->

                </div>  
                
            </div>

        </div>

        <div class="row copyrights">
            <div class="col-lg-6">
                <span>2024 © LuLu Mall</span>
            </div>
            <div class="col-lg-6 text-end">
                <span>Powered By LuLu Mall Business Suite</span>
            </div>
        </div>
        <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>
    </div>
	
	
	<div class="modal fade zoomIn" id="deleteRecordModal" tabindex="-1"
                                    aria-labelledby="deleteRecordLabel" aria-hidden="true">
                                    <div class="modal-dialog modal-dialog-centered">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                    aria-label="Close" id="btn-close"></button>
                                            </div>
                                            <div class="modal-body p-5 text-center">
                                                <i class="fas fa-trash-alt" style="font-size: 70px;"></i>
                                                <div class="mt-4 text-center">
                                                    <h4 class="fs-semibold">You are about to delete a User ?</h4>
                                                    <p class="text-muted fs-14 mb-4 pt-1">Deleting your User will remove
                                                        all of your information from our database.</p>
                                                    <div class="hstack gap-2 justify-content-center remove">
													<input type="hidden" name="delid" id="delid">
                                                        <button class="btn" id="deleteRecord-close"
                                                            data-bs-dismiss="modal"><i class="fas fa-times"></i>
                                                            Close</button>
                                                        <button class="btn" id="delete-record">Yes, Delete It!!</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>



<div class="modal fade" id="edit_model" role="dialog">
		<div class="modal-dialog">
			<div class="edit_model">
				
			</div>
		</div>
   </div>

<!--datatable css-->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/dataTables.bootstrap5.min.css" />
    <!--datatable responsive css-->
    <link rel="stylesheet" href="https://cdn.datatables.net/responsive/2.2.9/css/responsive.bootstrap.min.css" />

    <link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.2.2/css/buttons.dataTables.min.css">


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/plugins.js"></script>
    <script src="assets/js/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="lib/tempusdominus/js/moment.min.js"></script>
    <script src="lib/tempusdominus/js/moment-timezone.min.js"></script>
    <script src="lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>
    <script src="assets/js/main.js"></script>
	<script src="assets/js/lobibox.min.js"></script>
	
	
	
	<!--datatable js-->
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap5.min.js"></script>
    <script src="https://cdn.datatables.net/responsive/2.2.9/js/dataTables.responsive.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.2.2/js/dataTables.buttons.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.2.2/js/buttons.print.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.2.2/js/buttons.html5.min.js"></script>
    <script src="../../../../cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
    <script src="../../../../cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
    <script src="../../../../cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>

    <script src="assets/js/pages/datatables.init.js"></script>
	
	
	<script>
		 $("#create_user").submit(function(e) {
			  e.preventDefault();
			  
			  
			  var name 				= $('#name').val();
			  var email 			= $('#emailInput').val();
			  var password 			= $('#password').val();
			  var cPassword 		= $('#cPassword').val();
			  var hierarchy         = $('#hierarchy option:selected').val();
			  
			  if(name == ""){
				 Lobibox.notify('error', {
					size: 'mini',
					rounded: true,
					delayIndicator: false,
					position: "bottom right",
					sound: false, 
					msg: 'Please Enter the name'
				});
			  }else if(email == ""){
				  Lobibox.notify('error', {
					size: 'mini',
					rounded: true,
					delayIndicator: false,
					position: "bottom right",
					sound: false, 
					msg: 'Please Enter the E-mail'
				});
			  }else if(password == ""){
				  Lobibox.notify('error', {
					size: 'mini',
					rounded: true,
					delayIndicator: false,
					position: "bottom right",
					sound: false, 
					msg: 'Please Enter the Password'
				});
			  }else if(cPassword == ""){
				  Lobibox.notify('error', {
					size: 'mini',
					rounded: true,
					delayIndicator: false,
					position: "bottom right",
					sound: false, 
					msg: 'Please Enter the Confirm Password'
				});
			  }else if(password != cPassword){
				  Lobibox.notify('error', {
					size: 'mini',
					rounded: true,
					delayIndicator: false,
					position: "bottom right",
					sound: false, 
					msg: 'Password Not Match'
				});
			  }else if(hierarchy == 0){
				  Lobibox.notify('error', {
					size: 'mini',
					rounded: true,
					delayIndicator: false,
					position: "bottom right",
					sound: false, 
					msg: 'Please select the hierarchy'
				});
			  }else{
			  
			  var data = new FormData(this);
              var url = 'includes/ajax/CreateUser.php';
			  
			  $.ajax({
                type: 'POST',
                url: url,
                data: data, // send it here
                contentType: false, // this
                cache: false,
                processData: false, // and this should be false in case of uploading files
                beforeSend: function(xhr) {},
                success: function(Onj) {
					
					
					
					
						if(Onj.trim() === 'success'){
							
							Lobibox.notify('success', {
								size: 'mini',
								rounded: true,
								delayIndicator: false,
								position: "bottom right",
								sound: false, 
							   msg: 'User Updated Successfully'
						   });
							
							
							
							setTimeout(function() {
								location.reload();
							}, 2000);
							
							
						}else{
							Lobibox.notify('error', {
								size: 'mini',
								rounded: true,
								delayIndicator: false,
								position: "bottom right",
								sound: false, 
							   msg: 'Please check the credentials'
						   });
						}
				
                },
                error: function(data) {}
            });
			
		 }
		 });
		 
		 
		 
		 
		 function edit_user(id){
			 
			 
			 var modal = $('#edit_model');
			 modal.modal('show');
			 
			$('.edit_model').html('');
			
            var url = 'includes/ajax/EditUser.php';
			
			$.ajax({
                type: 'POST',
                url: url,
                data: {id:id},
                
                success: function(Onj) {
					
					
					$('.edit_model').html(Onj);
					
						
				
                },
                error: function(data) {}
            });
			 
			 
		 }
		 
		 
		 
		 
		 
		 function delete_user(id){
			 
			 
			 var modal = $('#deleteRecordModal');
			modal.find('input[name=delid]').val(id);
			modal.modal('show');
		 }
		 
		 $("#delete-record").click(function (e) {
			 e.preventDefault();
			
			var delid       = $('#delid').val();
			
            var url = 'includes/ajax/DeleteUser.php';
			
			$.ajax({
                type: 'POST',
                url: url,
                data: {id:delid},
                
                success: function(Onj) {
					
					
					
					
						if(Onj.trim() === 'success'){
							Lobibox.notify('success', {
								size: 'mini',
								rounded: true,
								delayIndicator: false,
								position: "bottom right",
								sound: false, 
							   msg: 'User Deleted Successfully'
						   });
							
							
							
							setTimeout(function() {
								location.reload();
							}, 2000);
						}else{
							Lobibox.notify('error', {
								size: 'mini',
								rounded: true,
								delayIndicator: false,
								position: "bottom right",
								sound: false, 
							   msg: 'User Not Deleted'
						   });
						}
				
                },
                error: function(data) {}
            });
			
			
			
			
		});
	
	$(document).ready(function() {
  $('#user').dataTable();
  
  $('#transcation').dataTable();
  
  
  new DataTable('#hie', {
    order: [[3, 'asc']]
});
});
	
	
	
	
	</script>
	
	
	
</body>




</html>