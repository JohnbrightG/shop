<?php

require '../config.php';


			$name 		      = $_POST['name'];
			$email 		      = $_POST['email'];
			$password 	      = password_hash($_POST['password'], PASSWORD_DEFAULT);
			$hierarchy 		  = $_POST['hierarchy'];
			$status 		  = 1;
			$created_at       =  date('d-m-Y h:i:s a');

			
			$sql = 'INSERT INTO store_users(name,email,password,hierarchy,status,created_at) VALUES(:name,:email,:password,:hierarchy,:status,:created_at)';

			$statement = $pdo->prepare($sql);

			$statement->execute([
				':name' 			    => $name,
				':email' 			    => $email,
				':password' 		    => $password,
				':hierarchy' 		    => $hierarchy,
				':status' 		        => $status,
				':created_at' 		    => $created_at
			]);
		
			$user_id = $pdo->lastInsertId();
			
			if($user_id){
				echo 'success';
			}else{
				echo 'failed';
			}
		




?>

